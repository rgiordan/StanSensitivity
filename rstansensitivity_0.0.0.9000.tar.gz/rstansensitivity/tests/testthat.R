#!/usr/bin/env Rscript
library(testthat)
library(rstansensitivity)

test_check("rstansensitivity")
