
  y <- 3.0
  prior_mean <- 0.0
  